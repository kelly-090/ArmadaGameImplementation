Joseph Tran, jt8387@rit.edu
Emily Fluckiger, eaf6022@rit.edu
Sohyun Yu, sy8556@rit.edu