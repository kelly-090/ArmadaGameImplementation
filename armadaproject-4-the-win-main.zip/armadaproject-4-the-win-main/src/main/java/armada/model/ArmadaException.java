package armada.model;

import java.lang.Exception;

public class ArmadaException extends Exception {
    public ArmadaException(String message){
        super(message);
    }
}
