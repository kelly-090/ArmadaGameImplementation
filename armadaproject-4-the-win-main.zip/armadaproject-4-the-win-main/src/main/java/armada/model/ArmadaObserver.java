package armada.model;

public interface ArmadaObserver {
    public abstract void updateBoard(Move move);
}
