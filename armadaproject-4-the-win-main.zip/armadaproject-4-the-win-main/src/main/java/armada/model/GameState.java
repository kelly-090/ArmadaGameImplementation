package armada.model;

public enum GameState {
    NEW,
    IN_PROGRESS,
    NO_MOVES,
    WON;
}
